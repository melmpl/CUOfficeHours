<?php

include("Functions551.inc");
$db = connectDB();


makeProf($db);
//makeHours($db);

function makeProf($db){
$string1 = "CREATE TABLE Professors ";
$string2 = "(";
        $string3 = "ProfPre    VARCHAR(30) , ";
$string4 = "ProfF VARCHAR(6), ";
$string5 = "ProfL VARCHAR(15) , ";
$string6 = "Department VARCHAR(8), ";
$string7 = "Office VARCHAR(40), ";
$string8 = "ProNetID VARCHAR(10) NOT NULL ";
$string99 = ");";

$query = $string1.$string2.$string3.$string4.$string5.$string6.$string7.$string8.$string99;
$result = mysqli_query($db, $query) or die('Query failed: ' .mysqli_error($db));
echo "Table Professors created . . . <br>";
echo "Would have run query: ".$query."<br>";
}

function makeHours($db){
// delete old table if present
// make new table
$string1 = "CREATE TABLE Hours";
$string2 = "(";
$string3 = "MonHrs    VARCHAR(11), ";
$string4 = "TueHrs   VARCHAR(11), ";
$string5 = "WedHrs    VARCHAR(11), ";
$string6 = "ThursHrs    VARCHAR(11), ";
$string7 = "FriHrs    VARCHAR(11) ";
$string99 = ");";

$query = $string1.$string2.$string3.$string4.$string5.$string6.$string7.$string99;
$result = mysqli_query($db, $query) or die('Query failed: ' .mysqli_error($db));
echo "Table Hours created . . . <br>";
echo "Would have run query: ".$query."<br>";
}

populateProf($db,"OfficeHoursDatabase.csv");
//populateHours($db,"OfficeHoursDatabase.csv");

function parseLine($sBuffer){
// fieldLength is 11

$myBuffer = $sBuffer;
        $iCount = 0;
$strLength = strlen($myBuffer);

if($strLength==0)
     return;

//echo "Buffer is ".$sBuffer."<br>";

for($i=0;$i<10;$i++){
  $nextComma = strpos($myBuffer,',');
  if($nextComma==0)
$aTokens[$iCount]=NULL;
  else
$aTokens[$iCount]=substr($myBuffer,0,$nextComma);
  $myBuffer=substr($myBuffer,$nextComma+1);
  $iCount++;
}
$aTokens[$iCount]=substr($myBuffer,0);

return $aTokens;
}


function populateProf($db,$filename){

$inFile = fopen($filename, "r");
if($inFile){
   $buffer = fgets($inFile, 4096);
echo "Fields: <br>";
echo "#".$buffer."#<br><br>";
echo "Data:";
   while (!feof($inFile)) {
     $buffer = fgets($inFile, 4096);
     $buffer = rtrim($buffer);
     if($buffer=="")

continue;
     $fields = parseLine($buffer);
      echo $fields[0].'#'.$fields[1].'#'.$fields[2].'#'.$fields[3].'#'.$fields[4].'#'.$fields[5].'#<br>';
      $string1 = "INSERT INTO Professors(ProfL,ProfPre,ProfF,ProfNetId,Department,Office) VALUES('$fields[0]','$fields[1]','$fields[2]','$fields[3]','$fields[4]','$fields[5]')";
       $result = mysqli_query($db, $string1) or die('Query failed: ' . mysqli_error());
    //echo "Query would have been ".$query."<br><br>";

            } // end while
        fclose($inFile);
        }// end if
 echo "Action completed on Professors.<br><br>";

}


?>

/*function populateHours($db,$filename){

$inFile = fopen($filename, "r");
if($inFile){
   $buffer = fgets($inFile, 4096);
echo "Fields: <br>";
echo "#".$buffer."#<br><br>";
echo "Data:";
   while (!feof($inFile)) {
     $buffer = fgets($inFile, 4096);
     $buffer = rtrim($buffer);
     if($buffer=="")

continue;
     $fields = parseLine($buffer);
      echo $fields[6].'#'.$fields[7].'#'.$fields[8].'#'.$fields[9].'#'.$fields[10].'#<br>';
      $string1 = "INSERT INTO Hours(MonHrs,TueHrs,WedHrs,ThursHrs,FriHrs) VALUES('$fields[6]','$fields[7]','$fields[8]','$fields[9]' '$fields[10]')";
       $result = mysqli_query($db, $string1) or die('Query failed: ' . mysqli_error());
    //echo "Query would have been ".$query."<br><br>";

            } // end while
        fclose($inFile);
        }// end if
 echo "Action completed on Professors.<br><br>";

}*/
